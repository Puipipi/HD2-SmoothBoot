SmoothBoot - quick guide / 快速指南
=====================================================

Candidate 3.0.50: isolates Windows FFI declarations with private aliases; restores each paused table by identity; preserves underscores in exclusions; reads and bounds reentry_max; safely formats foreign errors. New installs leave shared GC policy unchanged (gc_pause=0); explicit existing settings remain. Offline checks do not establish that reported in-game memory leaks or crashes are fixed. Restart to upgrade; live acceptance remains pending.
候选3.0.50：Windows FFI声明改用私有别名；按表身份恢复暂停状态；排除列表保留下划线；读取并限制reentry_max；安全处理异常文本。新安装默认不调整共享GC（gc_pause=0），已有显式配置保留。离线检查不足以证明反馈中的实机泄漏或崩溃已修复；升级需重启，实机验收仍待完成。

Candidate 3.0.49: removes C4-specific adapters and their configuration/diagnostics. Legacy keys are ignored. Boot-pause restoration now drops references to restored foreign state. Restart the game when upgrading; live acceptance remains pending.
候选3.0.49：移除C4专用适配器及其配置与诊断，旧配置项忽略；开局暂停恢复后释放对外部旧状态的引用。升级请重启游戏，实机验收仍待完成。
Candidate 3.0.48: adds a black-box line to the periodic self-report (`blackbox: head=<chain head> open=<n>[<held writers currently allowed to write>] held_closed=<n>`), built from the existing writer-hold table (`WH.held[name].ctl.open`). After a crash the last such line names the set of writers that could have been writing, which is what the dump alone cannot tell (the dump shows the victim instruction, never the writer). Purely additive: no change to the gate, the chain wrapper, timing or release logic.
Candidate 3.0.47: the original-chain pass-through now carries a bounded nesting depth instead of a boolean latch. A legal second dispatch in the same engine call (the shape the priority loaders above us use) is forwarded and still returns the chain's values; only past reentry_max (default 3, clamp 1..16) is a cycle broken, counted in M.reentry_cycles and logged with the depth and the cap. Arity, trailing nils and error identity are preserved on every path. This replaces 3.0.46's boolean swallow, which returned nothing to the caller and was followed by in-game menu, mission-entry and quit stalls on 2026-10-06. Offline suites cover the guard, the observed priority load order (smoothboot -> hd2runtime -> hd2_scanner) and the runtime scheduler; live acceptance is still open.
Candidate 3.0.46 (superseded): original-chain pass-through broke a second re-entry before timing or discovery. Legitimate adopted chains still reach their original downstream once. Success, errors and trailing nil results reset the guard correctly. HD2Runtime 0.28.1's unchanged scheduler has been replayed offline in both load orders; this is not live crash or performance acceptance.
候选3.0.47：原链直通改为有界嵌套深度，取代布尔锁存。同一次引擎调用内的合法二次派发（我们上方的优先加载模组正是这种形状）会被正常转发并仍能拿到链路返回值；只有超过 reentry_max（默认3，范围1..16）才断环，并计入 M.reentry_cycles、连同深度与上限写入日志。所有路径都保留返回值个数、末尾 nil 与异常对象本身。此项取代 3.0.46 的布尔吞掉——它会把空值返回给调用方，2026-10-06 实机随后出现菜单、入队与退出卡死。离线套件已覆盖守卫、实测优先加载顺序（smoothboot → hd2runtime → hd2_scanner）与 runtime 调度器；实机验收仍未完成。
候选3.0.46（已被取代）：原链直通路径在第二次重入时终止循环，保护发生在计时和识别之前。正常接回的调用链仍可转发至原链；成功、异常及末尾nil返回值均会正确复位保护。已离线回放HD2Runtime 0.28.1原始调度器的两种加载顺序；尚未完成实机崩溃与性能验收。

Release 3.0.45: writer hold gates now carry the delegated writer's name plus [SB gate] in source-based profilers. This identifies our routing shell, not a changed third-party file. Released writer work and the shell's forwarding overhead are charged to that row; SmoothBoot's governor keeps its own row. Profiler probes, callback results and release timing are preserved. No work is hidden or disabled to lower the displayed cost.
正式版3.0.45：写入保护门在按源码归属的性能面板中显示被托管模组名称及[SB gate]标记，明确表示这是我们的转发门，并非修改了第三方文件。释放后原模组的执行耗时与门本身的转发开销计入该行；SmoothBoot调度器仍保留独立一行。计时探针、回调返回值和释放时机保留；没有通过隐藏或禁用工作降低显示数值。
Accepted on 2026-10-04: live startup attribution and companion-tool generation, followed by user-operated mission, death/respawn and return-to-ship checks. This is an attribution maintenance release, not a claim of universal compatibility.
2026-10-04验收：实机启动归属与工具生成正常，用户操作的任务、死亡复活、返舰船检查正常。这是计时归属维护版，不承诺所有模组兼容。
Candidate 3.0.44 (bug-fix): the "cannot splice" note now distinguishes the two causes. If the wrapper above keeps no function upvalue as its previous hook, replacing hooks at runtime is why it sits above us and mod order cannot change that; the old wording told users to reorder a list that was already correct.
候选3.0.44（修复版）：把“无法插入”的提示分成两种真实原因。若上方包装层没有用函数 upvalue 保存上一个钩子，那是它运行期重包导致的，调整顺序也没用；旧文案会误导用户去改一个本来就正确的顺序。
Candidate 3.0.43 (bug-fix): collector exclude picker ignores "config check" lines; the config-check warning no longer contains the words "chain inventory"; the shipped LTE default explains itself and how to remove it; chain inventory is re-logged when it changes and unmanaged sources are listed separately; "rehooks" is logged once per source with an above-SmoothBoot note; the load-order hint is printed on the first frame.
候选3.0.43（修复版）：bat 排除选择器不再被 "config check" 行干扰；配置检查提示不再包含 "chain inventory" 字样；自带 LTE 默认项会说明自身及删除方法；链清单变化时重新打印，并单独列出无法托管的来源；"rehooks" 每个来源只提示一次并说明是否在 SmoothBoot 之上；首帧直接提示加载顺序问题。
Candidate 3.0.42 (diagnostic): self-timings of the wrapper sections outside the chain call, to settle the opening-cost attribution question.
候选3.0.42（诊断版）：为包装层中“链条调用之外”的各段加入自计时，用于判定开局开销到底是不是我们的。
Candidate 3.0.41: detects common drawing field accesses, captured graphics APIs and mod render hooks.
候选3.0.41：自动识别常见绘图接口、闭包引用与模组render回调，无需逐个添加名称。
Metadata is read only and cached; no foreign callback or graphics API is invoked by discovery.
只读取并缓存函数元数据；识别过程不执行第三方回调，不调用绘图接口。
Detected HUDs retain every update of their enclosing chain. This is not independent per-mod scheduling.
被识别HUD所在链条保留逐帧更新；这不是逐模组独立调度。
Unusual/dynamic/custom renderers may need the existing exclude list. Live acceptance remains required.
特殊、动态或自定义绘制仍可能需要排除名单，模拟测试不能代替实机验收。
Startup logs measure Smooth's own module-body initialization; pre-animation black-screen cause is unconfirmed.
启动日志记录Smooth自身初始化时间；片头前黑屏原因尚未确认，未宣称已经缩短黑屏。
Callback forwarding still avoids per-frame result tables and preserves trailing nil.
公共回调转发仍不逐帧创建返回值表，并保留末尾nil。
HUD Ballistic Trajectory, Enemy HP, DiversBestFriend and Aggro Counter callbacks
protect their enclosing chain from skipped/paused updates, including update buses.
弹道HUD、Enemy HP、DiversBestFriend和Aggro Counter所在调用链保留逐帧更新，兼容调度总线。
This protection is not selective per-mod scheduling.
此保护不是逐模组独立节流。
Watchdog can attribute work behind Smooth writer gates to Smooth. ms/s is accumulated
time per second, not one frame's latency. High startup scan cost may be temporary.
Watchdog可能把Smooth写入门后的工作归入Smooth。ms/s为每秒累计时间，不是单帧延迟。
Game functionality and reported cost regressions still require live acceptance.
游戏功能以及反馈的异常开销仍需实际游戏验收。

[Report an issue / 反馈问题]
  The game creates Collect-Logs.bat next to this README on first run
  (folder: %LOCALAPPDATA%\CowboyBingus\Helldivers2\SmoothBoot\).
  / 首次运行游戏后，本 README 旁边会自动生成 Collect-Logs.bat。
  This is the runtime config folder, not the mod manager import folder.
  此处是运行配置目录，不是模组管理器的安装目录。
  Open it by pasting the folder path above into File Explorer.
  将上方目录粘贴到文件资源管理器地址栏即可打开。
  1. Close the game / 关闭游戏
  2. Double-click Collect-Logs.bat / 双击 Collect-Logs.bat
  3. Type C and press Enter / 输入 C 回车
  4. Send the SmoothBoot-logs-*.zip from your Desktop with your report
     把桌面上的 SmoothBoot-logs-日期.zip 随问题报告一起发给作者

[Exclude one mod from SmoothBoot / 排除一个模组（不让它管）]
  1. Close the game / 关闭游戏
  2. Double-click Collect-Logs.bat / 双击 Collect-Logs.bat
  3. Type E and press Enter / 输入 E 回车
  4. Pick the mod by NUMBER and press Enter / 按数字选择模组，回车
  The exact name is written into config.txt for you - nothing to type,
  nothing to mistype. Existing exclusions are preserved; remove only this name to undo.
  精确名称会自动合并进 config.txt 的 exclude= 列表；保留已有排除项，移除该名称即可撤销。

[Advanced: manual config editing / 进阶：手动改配置]
  Edit config.txt in this folder; changes hot-apply within 10 seconds.
  / 编辑本文件夹里的 config.txt，10 秒内热生效。
  enabled=yes/no        master switch / 总开关
  reentry_max=3         nested dispatch cap, integer 1..16 / 嵌套派发上限，整数1..16
  exclude=FRAG,...      never manage these mods / 排除托管
  writers=FRAG,...      writer mods held at boot / 开机扣留的写入器
  writer_release_s=10   seconds before first release / 首个放行延时
  writer_stagger_s=8    seconds between releases / 放行间隔
  writer_min_stagger_s=8 minimum release interval / 最短放行间隔
  snapshot=no          deep diagnostic snapshots (off by default) / 深度快照默认关闭
  writer_norelease=FRAG never released / 永不放行
    NOTE: the m103 FRV turret writer is held permanently BY DEFAULT - its
    delayed write crashed 3/3 test sessions. To re-enable it at your own
    risk, set: writer_norelease= (empty value) in config.txt.
    / 默认永久扣留 m103 炮塔写入器（其延迟写入实测必崩）；自担风险放开：
    / 在 config.txt 写一行 writer_norelease= （等号后留空）
  ui_chunks=FRAG,...    frame-critical mods / 关键帧模组保护
  No compatibility popup: timing and registration cannot prove lost functionality.
  / 没有兼容弹窗：耗时和注册状态不能证明第三方功能被破坏。
  LTE Helmet and Cape Passives is excluded by default after the reported variant issue.
  / 默认排除LTE头盔/披风被动模组；Armor Transmog没有新增排除。
  throttle=auto/yes/no, diag=yes/no ...
  Where do fragments come from? The "chain inventory" line in SmoothBoot.log
  lists every mod's exact name - copy any unique piece. If you mistype one,
  the log will say: config check: ... did you mean "..."?
  / 片段来自 SmoothBoot.log 里的 "chain inventory" 行；填错时日志会提示正确名称。
  Only sources reachable on the update chain can be listed or excluded. A mod
  that hooks the engine elsewhere (menus, native render, its own timer) can be
  neither scheduled nor excluded; the log prints those as "NOT managed".
  / 只有 update 链上够得到的模组才能被列出或排除；挂在别处（菜单、原生渲染、
  自己的计时器）的模组既不能被调度也不能被排除，日志会用 "NOT managed" 标出。
  Load order: keep SmoothBoot at the BOTTOM of the list (just below Bingus Shared Loader).
Measured 2026-10-06: at the bottom it loads early, so later writers keep us as their
downstream and the writer gate can hold them - the watchdog then shows `mods/<owner>
[SB gate]` rows (275 rows across five owners, including two mods that are not in writers=)
and the log shows writer-hold releases. Moved to the TOP it loaded 61st of 61, the watchdog
showed NO [SB gate] row, and the gate held nothing: every writer had installed first.
Purge and Deploy after any reorder.
Superseded (wrong) wording kept below as history: Arsenal's **default priority** reads the list bottom-up - the bottom entry
loads first (innermost) and the top entry loads last (outermost wrapper). Measured
2026-10-06: SmoothBoot sat at the bottom (index 75/76, patch slot 336, the highest) and
was therefore loaded 13th of 62, i.e. *inside* hd2runtime and hd2_scanner. To let
SmoothBoot wrap the whole chain, put it at the **top** of the list and keep the loader
itself at the bottom (that is the loader's own rule). If you enabled Arsenal's
first-mod priority instead, the mapping inverts: then SmoothBoot belongs at the bottom.
Purge and Deploy after reordering.
Candidate notes keep the older wording below as history. If another
  mod wraps the chain above it, the first-frame line says so and lists the head.
  加载顺序：Arsenal 的**默认优先级**是按列表自下而上读取——最底部先加载（最内层），
（该解读已被实测推翻，见下方更正）。2026-10-06 实测：SmoothBoot 位于最底部（第 75/76 位、
部署槽位 336 即最高），结果在 62 个模组里第 13 个加载，即被 hd2runtime 与 hd2_scanner
包在里面。若要让它包住整条链，应把它保持在列表**最底部**（实测：放底部时写入门有效），而加载器本身保持最底部
（那是加载器自己的规则）。若你启用了 Arsenal 的“首模优先”，映射相反：此时 SmoothBoot
应放最底部。改完顺序后要 Purge → Deploy。
/ 旧表述保留在下方作为历史：若有模组在它上面包住链，
  首帧日志会直接写出链头名字并提示调整顺序。
  Self re-heading only works when the newcomer keeps us in a function upvalue.
  A mod that re-wraps update at runtime and stores its previous hook elsewhere
  (table field, native callback, its own timer) CANNOT be spliced without
  risking its chain: SmoothBoot deliberately leaves it above and says why.
  Putting SmoothBoot lower cannot change that case - the log names the reason.
  / 自我重接管只在“后来者把我们保存在函数 upvalue 里”时有效。若某个模组在运行期
  重包 update，并把上一个钩子存在别处（表字段、原生回调、自己的计时器），硬插进去
  就可能弄坏它的链条，所以我们宁可让它待在上面并写明原因；这种情况下再怎么调整
  顺序也没用，日志会直接告诉你属于哪一种。

[About Mod Lag Watchdog / 关于 watchdog]
  It may report "hooking more than once: smoothboot xN" - that is expected
  (1 governor wrapper + N gates). Its ms/s column can read high for some
  mods. SmoothBoot stats measure only its managed chain; compare call counts
  and the same scene before attributing an individual mod cost.
  / stats 只记录托管链，不能据此否定看门狗读数；请结合调用次数与同场景数据判断。
