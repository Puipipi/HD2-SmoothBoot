SmoothBoot - quick guide / 快速指南
=====================================================

[Report an issue / 反馈问题]
  The game creates Collect-Logs.bat next to this README on first run
  (folder: %LOCALAPPDATA%\CowboyBingus\Helldivers2\SmoothBoot\).
  / 首次运行游戏后，本 README 旁边会自动生成 Collect-Logs.bat。
  This is the runtime config folder, not the mod manager import folder.
  此处是运行配置目录，不是模组管理器的安装目录。
  Open it by pasting the folder path above into File Explorer.
  将上方目录粘贴到文件资源管理器地址栏即可打开。
  1. Close the game / 关闭游戏
  2. Double-click Collect-Logs.bat / 双击 Collect-Logs.bat
  3. Type C and press Enter / 输入 C 回车
  4. Send the SmoothBoot-logs-*.zip from your Desktop with your report
     把桌面上的 SmoothBoot-logs-日期.zip 随问题报告一起发给作者

[Exclude one mod from SmoothBoot / 排除一个模组（不让它管）]
  1. Close the game / 关闭游戏
  2. Double-click Collect-Logs.bat / 双击 Collect-Logs.bat
  3. Type E and press Enter / 输入 E 回车
  4. Pick the mod by NUMBER and press Enter / 按数字选择模组，回车
  The exact name is written into config.txt for you - nothing to type,
  nothing to mistype. Existing exclusions are preserved; remove only this name to undo.
  精确名称会自动合并进 config.txt 的 exclude= 列表；保留已有排除项，移除该名称即可撤销。

[Advanced: manual config editing / 进阶：手动改配置]
  Edit config.txt in this folder; changes hot-apply within 10 seconds.
  / 编辑本文件夹里的 config.txt，10 秒内热生效。
  enabled=yes/no        master switch / 总开关
  exclude=FRAG,...      never manage these mods / 排除托管
  writers=FRAG,...      writer mods held at boot / 开机扣留的写入器
  writer_release_s=10   seconds before first release / 首个放行延时
  writer_stagger_s=8    seconds between releases / 放行间隔
  writer_min_stagger_s=8 minimum release interval / 最短放行间隔
  snapshot=no          deep diagnostic snapshots (off by default) / 深度快照默认关闭
  writer_norelease=FRAG never released / 永不放行
    NOTE: the m103 FRV turret writer is held permanently BY DEFAULT - its
    delayed write crashed 3/3 test sessions. To re-enable it at your own
    risk, set: writer_norelease= (empty value) in config.txt.
    / 默认永久扣留 m103 炮塔写入器（其延迟写入实测必崩）；自担风险放开：
    / 在 config.txt 写一行 writer_norelease= （等号后留空）
  ui_chunks=FRAG,...    frame-critical mods / 关键帧模组保护
  throttle=auto/yes/no, hud=on/off, diag=yes/no ...
  Where do fragments come from? The "chain inventory" line in SmoothBoot.log
  lists every mod's exact name - copy any unique piece. If you mistype one,
  the log will say: config check: ... did you mean "..."?
  / 片段来自 SmoothBoot.log 里的 "chain inventory" 行；填错时日志会提示正确名称。

[About Mod Lag Watchdog / 关于 watchdog]
  It may report "hooking more than once: smoothboot xN" - that is expected
  (1 governor wrapper + N gates). Its ms/s column can read high for some
  mods. SmoothBoot stats measure only its managed chain; compare call counts
  and the same scene before attributing an individual mod cost.
  / stats 只记录托管链，不能据此否定看门狗读数；请结合调用次数与同场景数据判断。
